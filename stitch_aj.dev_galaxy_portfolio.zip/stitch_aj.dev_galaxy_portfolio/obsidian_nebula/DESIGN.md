---
name: Obsidian Nebula
colors:
  surface: '#0f1321'
  surface-dim: '#0f1321'
  surface-bright: '#353849'
  surface-container-lowest: '#0a0d1c'
  surface-container-low: '#171b2a'
  surface-container: '#1b1f2e'
  surface-container-high: '#262939'
  surface-container-highest: '#303444'
  on-surface: '#dfe1f6'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe1f6'
  inverse-on-surface: '#2c303f'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#ecb2ff'
  on-secondary: '#520071'
  secondary-container: '#cf5cff'
  on-secondary-container: '#480063'
  tertiary: '#fff3f4'
  on-tertiary: '#650031'
  tertiary-container: '#ffccd9'
  on-tertiary-container: '#b90760'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#f8d8ff'
  secondary-fixed-dim: '#ecb2ff'
  on-secondary-fixed: '#320047'
  on-secondary-fixed-variant: '#74009f'
  tertiary-fixed: '#ffd9e2'
  tertiary-fixed-dim: '#ffb1c7'
  on-tertiary-fixed: '#3f001c'
  on-tertiary-fixed-variant: '#8e0048'
  background: '#0f1321'
  on-background: '#dfe1f6'
  surface-variant: '#303444'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 80px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  section-padding-desktop: 120px
  section-padding-mobile: 64px
---

## Brand & Style
The design system is engineered for a high-end developer portfolio that merges technical precision with cinematic immersion. The brand personality is "The Architect of the Digital Void"—sophisticated, forward-thinking, and hyper-competent. It targets recruiters and tech founders who value craft and attention to detail.

The visual style is a hybrid of **Glassmorphism** and **Futuristic Minimalism**. It utilizes deep, multi-layered dark backgrounds to create an "infinite canvas" feel. High-fidelity glass surfaces provide structural hierarchy, while vibrant neon accents act as directional light sources, mimicking the glow of nebulae against the vacuum of space. The emotional response should be one of awe, reliability, and technological mastery.

## Colors
The palette is rooted in the "Void" (#050816), providing a base for high-contrast interactions. 

- **Primary (Electric Cyan):** Used for primary actions, success states, and code highlights. It represents energy and connectivity.
- **Secondary (Neon Purple):** Used for hover states, secondary branding elements, and decorative gradients.
- **Tertiary (Soft Pink):** Reserved for delicate highlights and warm accents in 3D-lit environments.
- **Neutral:** A range of deep indigos and charcoals are used to differentiate content containers from the infinite background.

Apply gradients sparingly using a "light-source" logic—colors should appear to radiate from specific points in the UI rather than being flatly applied.

## Typography
The typography strategy contrasts technical geometric headlines with highly legible sans-serif body text. 

- **Headlines:** Use **Space Grotesk** for all display and heading levels. Tighten letter spacing on larger sizes to create a "dense" cinematic feel. 
- **Body:** Use **Inter** for all descriptive text. It maintains clarity against dark, textured backgrounds.
- **Data & Code:** Use **JetBrains Mono** (or a system monospaced font) for technical specs, labels, and code snippets to reinforce the developer-centric nature of the portfolio.
- **Hierarchy:** Use the `label-caps` style for small descriptors above headlines to establish a structured, "modular" aesthetic.

## Layout & Spacing
The layout uses a **Fluid 12-column grid** on desktop and a **4-column grid** on mobile. 

- **Negative Space:** Embrace significant vertical padding between sections (120px+) to allow the "galaxy" background effects to breathe.
- **Alignment:** Content should predominantly be center-aligned for hero sections and left-aligned for data-heavy project details.
- **Micro-spacing:** Use an 8px base grid. All margins and paddings must be multiples of 8.
- **Glass Insets:** Cards and containers should use generous internal padding (32px to 48px) to emphasize the translucency and "protective" nature of the glass surfaces.

## Elevation & Depth
Depth is the most critical aspect of this design system. It is achieved through **Glassmorphism** and **Backdrop Blurs**.

1.  **Level 0 (The Void):** The base background (#050816). This layer often contains animated particles or parallax wireframe planets.
2.  **Level 1 (The Nebula):** Diffused radial gradients of Primary/Secondary colors at 5%–10% opacity, sitting behind the glass containers.
3.  **Level 2 (Glass Containers):** Semi-transparent surfaces (`rgba(255, 255, 255, 0.03)`) with a 16px to 24px backdrop-filter blur. 
4.  **Level 3 (Interactive Elements):** Buttons and active states that use a subtle white inner-glow or a 1px solid border (`rgba(255, 255, 255, 0.1)`) to "catch the light."

**Shadows:** Avoid traditional black shadows. Instead, use "Glow Shadows"—low-opacity drop shadows that match the color of the element (e.g., a Cyan button has a soft Cyan outer glow).

## Shapes
The shape language is "Soft-Tech." While the typography is sharp and geometric, the UI surfaces are welcoming and organic.

- **Standard Radius:** 16px (rounded-lg) for main content cards.
- **Feature Radius:** 24px (rounded-xl) for hero sections and large image containers.
- **Interactive Radius:** 8px to 12px for buttons and inputs.
- **Decorative:** Use perfect circles for "glowing orb" background elements and 1px thin strokes for wireframe planetary paths.

## Components

- **Buttons:** Primary buttons should be "Glow Buttons"—solid primary color text on a glass background with a high-intensity border. Secondary buttons are "Ghost" style with a 1px white/10% border that brightens on hover.
- **Glass Cards:** Must include a 1px top-left highlight border (white/20%) and a bottom-right shadow border (black/20%) to simulate 3D thickness.
- **Chips/Tags:** Use `label-caps` typography inside 4px rounded glass containers with a subtle primary color tint.
- **Input Fields:** Darker than the card background (#050816) with a subtle "focus" glow that expands the primary color along the bottom border.
- **Lists:** Use custom "binary" bullets (0/1) or geometric chevrons in the primary accent color.
- **Navigation:** A floating "Dock" style navigation bar at the bottom or top, featuring high backdrop-blur and ultra-rounded corners.
- **Specialty Components:** 
    - **Code Terminal:** A window-styled container with "traffic light" close/min/max buttons in greyscale.
    - **Project Timeline:** A vertical wireframe line with glowing nodes.